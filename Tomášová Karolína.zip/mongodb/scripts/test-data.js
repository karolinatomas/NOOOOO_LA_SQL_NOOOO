#!/bin/bash

mongosh <<EOF

EOF
